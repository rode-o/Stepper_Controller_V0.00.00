/*
 * File: config.cpp
 * Brief: Provides global configuration factors and default initialization.
 */

 #include "config.h"
 
 // Loads default configurations if needed
 void loadDefaults() {
   // Example initialization
   // calFactor = 1.0f;
 }
 