#pragma once
#include "system_state.h"

void reportAllStateJSON(const SystemState &s);
